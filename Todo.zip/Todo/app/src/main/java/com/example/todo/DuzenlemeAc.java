package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DuzenlemeAc extends AppCompatActivity {
    TextView gelenTXT,gelenED;
    Button gelenBTN;
    Veritabani vt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_duzenleme);
        gelenTXT=findViewById(R.id.txtGelenNot);
        gelenED=findViewById(R.id.edGelenAd);
        gelenBTN=findViewById(R.id.btnGelenDegistir);
        final String gelenString = getIntent().getStringExtra("adi");
        gelenTXT.setText(gelenString);
        vt = new Veritabani(DuzenlemeAc.this);
        gelenBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vt.notGuncelle(gelenString,gelenED.getText().toString());
                startActivity(new Intent(DuzenlemeAc.this,MainActivity.class));
                finish();
            }
        });
    }
}
