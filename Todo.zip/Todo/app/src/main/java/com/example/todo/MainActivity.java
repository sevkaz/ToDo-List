package com.example.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    ListView liste;
    FloatingActionButton fabE;
    Veritabani vt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        liste=findViewById(R.id.lvListe);
        fabE=findViewById(R.id.fabEkle);
        vt = new Veritabani(MainActivity.this);
        NotlarAdapter adap = new NotlarAdapter(MainActivity.this,vt.notlariGetir());
        liste.setAdapter(adap);
        fabE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,EklemeAc.class));
            }
        });
    }
}
