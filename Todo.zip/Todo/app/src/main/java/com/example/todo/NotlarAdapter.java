package com.example.todo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class NotlarAdapter extends BaseAdapter {
    List<Notlar> list;
    LayoutInflater inf;

    public NotlarAdapter(Activity activity,List<Notlar> Alist) {
        this.list = Alist;
        this.inf = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final View view;
        view=inf.inflate(R.layout.item_layout,null);
        TextView itemTXT = view.findViewById(R.id.txtItem);
        Button silBTN = view.findViewById(R.id.btnItemSil);
        Button duzenleBTN = view.findViewById(R.id.btnItemDuzenle);
        final Veritabani vt = new Veritabani(view.getContext());
        final Notlar not = list.get(position);
        itemTXT.setText(not.getAdi());
        silBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vt.notSil(not.getAdi());
                view.getContext().startActivity(new Intent(view.getContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
            }
        });
        duzenleBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent git = new Intent(view.getContext(),DuzenlemeAc.class);
                git.putExtra("adi",not.getAdi());
                view.getContext().startActivity(git);
            }
        });

        return view;
    }
}
