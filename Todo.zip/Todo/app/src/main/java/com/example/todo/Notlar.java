package com.example.todo;

import java.io.Serializable;

public class Notlar implements Serializable {
    private String Adi;

    public Notlar(String adi) {
        Adi = adi;
    }

    public Notlar() {
    }

    public String getAdi() {
        return Adi;
    }

    public void setAdi(String adi) {
        Adi = adi;
    }
}
