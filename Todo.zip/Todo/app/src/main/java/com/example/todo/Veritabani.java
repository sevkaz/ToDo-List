package com.example.todo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class Veritabani extends SQLiteOpenHelper {

    public static final String VT_ADI="todo";
    public static final String TABLO_ADI="notlar";
    private static final String Adi = "Adi";

    public Veritabani(Context context) {
        super(context, VT_ADI,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlCumlesi = "CREATE TABLE "+TABLO_ADI+"(id INTEGER PRIMARY KEY AUTOINCREMENT,"+Adi+" TEXT) ";
        db.execSQL(sqlCumlesi);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void notEkle(Notlar Notlar){
        SQLiteDatabase vt = this.getWritableDatabase();
        ContentValues veri = new ContentValues();
        veri.put("adi",Notlar.getAdi());
        vt.insert(TABLO_ADI,null,veri);
        vt.close();


    }

    public List<Notlar> notlariGetir(){
        SQLiteDatabase vc = this.getReadableDatabase();
        List<Notlar> not = new ArrayList<>();
        String sqlCumlesi = "SELECT * FROM "+TABLO_ADI;
        Cursor cursorNesnesi = vc.rawQuery(sqlCumlesi,null);
        while (cursorNesnesi.moveToNext()){
            Notlar notlar = new Notlar();
            notlar.setAdi(cursorNesnesi.getString(1));
            not.add(notlar);

        }

        return not;
    }

    public void notSil(String notAdi){
        SQLiteDatabase vd= this.getWritableDatabase();
        String sqlCumlesi = "DELETE FROM "+ TABLO_ADI +" WHERE adi='"+notAdi+"\'";
        vd.execSQL(sqlCumlesi);

    }
    public void notGuncelle (String eskiNotAdi,String notAdi){
        SQLiteDatabase db = getWritableDatabase();
        try {
            ContentValues cv = new ContentValues();
            cv.put("Adi", notAdi);
            db.update(TABLO_ADI,cv, Adi +" = '"+ eskiNotAdi + "'",null);
        }catch (Exception e){
        }
        db.close();




    }


}
